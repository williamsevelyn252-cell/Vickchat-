import 'package:flutter/material.dart';

void main() => runApp(const VickChatApp());

const purple = Color(0xFF7028A8);
const deepPurple = Color(0xFF481078);
const palePurple = Color(0xFFEDE1F7);

class VickChatApp extends StatelessWidget {
  const VickChatApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'VickChat',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: purple, primary: purple),
        scaffoldBackgroundColor: const Color(0xFFFCFAFE),
        fontFamily: 'Roboto',
        appBarTheme: const AppBarTheme(
          backgroundColor: purple,
          foregroundColor: Colors.white,
          elevation: 0,
          centerTitle: false,
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: Colors.white,
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 15),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: const BorderSide(color: palePurple),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: const BorderSide(color: palePurple),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: const BorderSide(color: purple, width: 1.5),
          ),
        ),
      ),
      home: const SplashScreen(),
    );
  }
}

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});
  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(seconds: 2), () {
      if (mounted) {
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const WelcomeScreen()));
      }
    });
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    body: Container(
      width: double.infinity,
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Colors.white, Color(0xFFF1E6FB), purple, deepPurple],
          stops: [0, .35, .75, 1],
        ),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 112, height: 112,
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(32)),
            child: const Icon(Icons.forum_rounded, size: 70, color: purple),
          ),
          const SizedBox(height: 18),
          const Text('VickChat', style: TextStyle(fontSize: 38, fontWeight: FontWeight.w900, color: deepPurple)),
          const SizedBox(height: 8),
          const Text('Connect. Communicate. Share.', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w600, color: deepPurple)),
          const SizedBox(height: 44),
          const CircularProgressIndicator(color: Colors.white, strokeWidth: 2.5),
        ],
      ),
    ),
  );
}

class WelcomeScreen extends StatelessWidget {
  const WelcomeScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    body: SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(26),
        child: Column(
          children: [
            const Spacer(),
            Container(
              height: 250, width: double.infinity,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(32),
                gradient: const LinearGradient(colors: [purple, deepPurple]),
              ),
              child: const Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.people_alt_rounded, color: Colors.white, size: 92),
                  SizedBox(height: 18),
                  Text('Your people. Your moments.', style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)),
                ],
              ),
            ),
            const SizedBox(height: 32),
            const Text('Welcome to VickChat', style: TextStyle(fontSize: 29, fontWeight: FontWeight.w900, color: deepPurple)),
            const SizedBox(height: 10),
            const Text('Chat, share moments and make meaningful connections.', textAlign: TextAlign.center, style: TextStyle(fontSize: 16, color: Colors.black54, height: 1.4)),
            const Spacer(),
            PrimaryButton(label: 'Get Started', onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const RegisterScreen()))),
            const SizedBox(height: 12),
            OutlinedButton(
              style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(54), foregroundColor: purple, side: const BorderSide(color: purple), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const LoginScreen())),
              child: const Text('Login', style: TextStyle(fontWeight: FontWeight.bold)),
            ),
            const SizedBox(height: 18),
          ],
        ),
      ),
    ),
  );
}

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});
  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final name = TextEditingController();
  final username = TextEditingController();
  final email = TextEditingController();
  final phone = TextEditingController();
  final password = TextEditingController();
  final confirm = TextEditingController();
  String gender = 'Prefer not to say';

  @override
  void dispose() {
    name.dispose(); username.dispose(); email.dispose(); phone.dispose();
    password.dispose(); confirm.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Create account')),
    body: SafeArea(
      child: ListView(
        padding: const EdgeInsets.all(22),
        children: [
          const Center(child: Icon(Icons.forum_rounded, color: purple, size: 58)),
          const Center(child: Text('Join the VickChat community', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: deepPurple))),
          const SizedBox(height: 22),
          field('Full name', Icons.person_outline, name),
          field('Username', Icons.alternate_email, username),
          field('Email address', Icons.email_outlined, email, keyboard: TextInputType.emailAddress),
          field('Phone number', Icons.phone_outlined, phone, keyboard: TextInputType.phone),
          field('Password', Icons.lock_outline, password, obscure: true),
          field('Confirm password', Icons.lock_reset, confirm, obscure: true),
          const SizedBox(height: 4),
          DropdownButtonFormField<String>(
            value: gender,
            decoration: const InputDecoration(labelText: 'Gender', prefixIcon: Icon(Icons.people_outline)),
            items: ['Prefer not to say', 'Female', 'Male', 'Other'].map((v) => DropdownMenuItem(value: v, child: Text(v))).toList(),
            onChanged: (v) => setState(() => gender = v ?? gender),
          ),
          const SizedBox(height: 14),
          const Text('Date of birth will be added to the secure sign-up flow when backend authentication is connected.', style: TextStyle(color: Colors.black54, fontSize: 12)),
          const SizedBox(height: 20),
          PrimaryButton(label: 'Create account', onPressed: () {
            ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('UI preview only — account creation will work after backend setup.')));
          }),
          const SizedBox(height: 12),
          TextButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const LoginScreen())), child: const Text('Already have an account? Login')),
        ],
      ),
    ),
  );

  Widget field(String label, IconData icon, TextEditingController controller, {bool obscure = false, TextInputType? keyboard}) =>
    Padding(padding: const EdgeInsets.only(bottom: 12), child: TextField(controller: controller, obscureText: obscure, keyboardType: keyboard, decoration: InputDecoration(labelText: label, prefixIcon: Icon(icon))));
}

class LoginScreen extends StatelessWidget {
  const LoginScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final email = TextEditingController();
    final password = TextEditingController();
    return Scaffold(
      appBar: AppBar(title: const Text('Login')),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.forum_rounded, color: purple, size: 70),
            const Text('Welcome back', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900, color: deepPurple)),
            const SizedBox(height: 28),
            TextField(controller: email, decoration: const InputDecoration(labelText: 'Email or phone number', prefixIcon: Icon(Icons.person_outline))),
            const SizedBox(height: 14),
            TextField(controller: password, obscureText: true, decoration: const InputDecoration(labelText: 'Password', prefixIcon: Icon(Icons.lock_outline))),
            const SizedBox(height: 22),
            PrimaryButton(label: 'Login', onPressed: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Login will be enabled after backend setup.')))),
            TextButton(onPressed: () {}, child: const Text('Forgot password?')),
          ],
        ),
      ),
    );
  }
}

class PrimaryButton extends StatelessWidget {
  final String label;
  final VoidCallback onPressed;
  const PrimaryButton({super.key, required this.label, required this.onPressed});
  @override
  Widget build(BuildContext context) => SizedBox(
    width: double.infinity, height: 54,
    child: FilledButton(
      style: FilledButton.styleFrom(backgroundColor: purple, foregroundColor: Colors.white, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
      onPressed: onPressed,
      child: Text(label, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
    ),
  );
}
