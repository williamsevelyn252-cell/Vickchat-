# VickChat

VickChat is an Android-first social networking and messaging app built with Flutter.

## Current milestone
This starter contains the first UI screens:
- Splash screen
- Welcome screen
- Registration UI
- Login UI

Authentication and account creation are UI placeholders until Supabase is connected.

## Run locally
1. Install Flutter SDK and Android Studio.
2. Open this folder in VS Code or Android Studio.
3. Run `flutter pub get`.
4. Run `flutter run`.

## Brand
- Purple: `#7028A8`
- Deep purple: `#481078`
- Light purple: `#EDE1F7`
- White: `#FFFFFF`

## Planned backend
Supabase Auth, Postgres, Storage and Realtime. LiveKit will be evaluated for voice/video calling.
